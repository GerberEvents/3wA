## Enoncé

Il faut tuer le dragon ou se faire tuer !

L'utilisateur saisit le niveau de difficulté, l'arme et l'armure puis le combat à mort commence...

Le vainqueur voit sa photo s'afficher en HTML :-)

## Détails

* Ce programme est un récapitulatif général de ce qui a été vu jusqu'à présent.
* Tout le jeu va se dérouler dans la console du navigateur web.
* Il est important d'organiser le code en petites fonctions afin de mieux comprendre le déroulement du jeu.